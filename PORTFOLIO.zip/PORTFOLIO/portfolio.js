$(document).ready(function(){
  $('#menu').click(function(){
   $(this).toogleClass('fa-times');
   $('header').toggleClass('toggle');
  });
  $(window).on('scroll load',function(){
    $('#menu').removeClass('fa-times');
    $('#header').removeClass('toogle');   
});
 });
