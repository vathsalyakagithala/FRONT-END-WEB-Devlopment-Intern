document.addEventListener('DOMContentLoaded', function() {
  console.log('DOMContentLoaded event fired');
  
  // Toggle search bar visibility
  document.getElementById('search-icon').addEventListener('click', function() {
    var searchBar = document.getElementById('search-bar');
    if (searchBar.style.display === 'none' || searchBar.style.display === '') {
      searchBar.style.display = 'block';
    } else {
      searchBar.style.display = 'none';
    }
  });

  // Handle scroll events
  document.addEventListener('scroll', function() {
    const homeSection = document.querySelector('.home'); // Assuming there's a .home section
    const scrollTopButton = document.querySelector('.scroll-top'); // Assuming there's a .scroll-top button
    const homeRect = homeSection.getBoundingClientRect();
  
    if (homeRect.bottom > window.innerHeight || homeRect.top < 0) {
      scrollTopButton.classList.add('visible');
    } else {
      scrollTopButton.classList.remove('visible');
    }
  });

  // Product list dynamic loading for newborn.html
  const productList = document.getElementById('product-list');
  
  // Check if the product list container exists
  if (productList) {
    fetch('product.json')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.json();
      })
      .then(data => {
        console.log('Product data fetched:', data);
        addDataToHTML(data);
      })
      .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
      });

    function addDataToHTML(products) {
      // Add new products to the container
      products.forEach(product => {
        let newProduct = document.createElement('div');
        newProduct.classList.add('item');
        newProduct.dataset.productId = product.id; // Assuming each product has an id
        newProduct.innerHTML = `
          <img src="${product.image}" alt="${product.name}">
          <h4>${product.name}</h4>
          <h5>₹${product.price}</h5>
        `;
        productList.appendChild(newProduct);

        // Add click event listener for each product to navigate to product details
        newProduct.addEventListener('click', function() {
          window.location.href = `product-details.html?id=${product.id}`; // Navigate to product details page
        });
      });
    }
  } else {
    console.error('Product list container not found!');
  }

  // Product details page functionality for product-details.html
  if (window.location.pathname.includes('product-details.html')) {
    const productImage = document.querySelector('.product-image');
    const productName = document.querySelector('.name');
    const productPrice = document.querySelector('.price');
    const productDescription = document.querySelector('.description');
    const similarProductsContainer = document.getElementById('similar-products-list');
  
    // Fetch product details based on id from URL parameter
    const productId = new URLSearchParams(window.location.search).get('id');
  
    fetch('product.json')
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.json();
      })
      .then(data => {
        const selectedProduct = data.find(product => product.id == productId);
        if (selectedProduct) {
          productImage.src = selectedProduct.image;
          productName.textContent = selectedProduct.name;
          productPrice.textContent = `₹${selectedProduct.price}`;
          productDescription.textContent = selectedProduct.description;
          
          // Display similar products
          displaySimilarProducts(data, selectedProduct.id);
        } else {
          console.error('Product not found!');
        }
      })
      .catch(error => {
        console.error('There was a problem with fetching product details:', error);
      });
  }
  
  function displaySimilarProducts(products, currentProductId) {
    const similarProductsContainer = document.getElementById('similar-products-list');
    if (similarProductsContainer) {
      // Find the index of the current product
      const currentIndex = products.findIndex(product => product.id == currentProductId);
      
      // Get the next 3 products
      const similarProducts = products.slice(currentIndex + 1, currentIndex + 4);

      // Display similar products
      similarProducts.forEach(product => {
        let similarProduct = document.createElement('div');
        similarProduct.classList.add('item');
        similarProduct.innerHTML = `
          <img src="${product.image}" alt="${product.name}">
          <h4>${product.name}</h4>
          <h5>₹${product.price}</h5>
        `;
        similarProduct.addEventListener('click', function() {
          window.location.href = `product-details.html?id=${product.id}`; // Navigate to product details page
        });
        similarProductsContainer.appendChild(similarProduct);
      });
    } else {
      console.error('Similar products container not found!');
    }
  }

  
});